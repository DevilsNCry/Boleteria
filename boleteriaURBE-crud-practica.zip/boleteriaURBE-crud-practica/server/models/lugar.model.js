'use strict';

module.exports = class Lugar {
    constructor(
        nombre,
    

    ) {
        this.nombre = nombre;
       
    }
};