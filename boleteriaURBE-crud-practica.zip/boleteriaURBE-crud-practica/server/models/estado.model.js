'use strict';

module.exports = class Estado {
    constructor(
        estado,
        fkbutaca
    ) {
        this.estado = estado;
        this.fkbutaca = fkbutaca;
    }
};