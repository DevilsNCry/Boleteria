# Servicios listos

1. Usuarios: Se pueden añadir, modificar, eliminar (desactivar) y obtener usuarios.